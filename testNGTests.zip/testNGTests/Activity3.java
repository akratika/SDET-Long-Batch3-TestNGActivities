package testNGTests;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Activity3 {
  WebDriver driver;
  
  @BeforeClass
  public void driverInstance() {
	  driver= new ChromeDriver();
	  driver.get("https://www.training-support.net/selenium/login-form");
	  driver.manage().window().maximize();
  }
  
  @Test
  public void login() {
	  WebElement uname= driver.findElement(By.xpath("//input[@id='username']"));
	  WebElement pwd = driver.findElement(By.xpath("//input[@id='password']"));
	  WebElement loginButton = driver.findElement(By.xpath("//button[contains(text(),'Log in')]"));
	  String messagePath = "//div[@id='action-confirmation']";
	  WebElement message = driver.findElement(By.xpath(messagePath));
	  WebDriverWait wait = new WebDriverWait(driver, 40);
	  
	  uname.sendKeys("admin");
	  pwd.sendKeys("password");
	  System.out.println("Credentials entered successfully.");
	  loginButton.click();
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(messagePath)));
	  Assert.assertEquals("Welcome Back, admin",message.getText());
	  
	  
  }

  @AfterClass
  public void closeBrowser() {
	  driver.close();
  }

}
