package testNGTests;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;

public class Activity2 {
	WebDriver driver;
	
@BeforeClass
	public void driverInstance() {
		driver= new ChromeDriver();
		driver.get("https://www.training-support.net/selenium/target-practice");
	}
@Test
  public void firstTest() {
	String title = driver.getTitle();
	System.out.println(title);
	Assert.assertEquals("Target Practice", title);
  }
@Test
	public void secondTest() {
		WebElement blackButton = driver.findElement(By.xpath("//button[@class='ui black button']"));
		Assert.assertEquals("Blue", blackButton.getText());
	}
@Test (enabled = false)
	public void thirdTest() {
		System.out.println("This method is meant for Skipped.");
	}
@Test
	public void fourthTest() {
		String skipMethod = "True";
		if(skipMethod.equals("True")) {
			throw new SkipException("This is fourth Test- meant for skip.");
		}
	}

 @AfterClass
 	public void closeBrowser() {
	 	driver.close();
  	}

}
