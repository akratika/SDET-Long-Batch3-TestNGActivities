package testNGTests;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.IReporter;
import org.testng.Reporter;

public class Activity9 {
	WebDriver driver;
	
  @Test(priority=0)
  public void simpleAlertTestCase() {
	  Reporter.log("Simple Alert Case Started |");
	  driver.findElement(By.xpath("//button[@id='simple']")).click();
	  Reporter.log("Simple Alert button Clicked |");
	  
	  Alert simpleAlert = driver.switchTo().alert();
	  Reporter.log("Switched to Simple Alert |");
	  
	  String simpleAlertText = simpleAlert.getText();
	  Reporter.log("Simple Alert Text is: "+ simpleAlertText+" |");
	  
	  simpleAlert.accept();
	  Reporter.log("Simple Alert Accepted |");
	  
	  Reporter.log("Simple Alert Case Ended |");
  }
  
  @Test(priority=1)
  public void confirmAlertTestCase() {
	  Reporter.log("Confirmation Alert Case Started |");
	  driver.findElement(By.xpath("//button[@id='confirm']")).click();
	  Reporter.log("Confirmation Alert button Clicked |");
	  
	  Alert confirmAlert = driver.switchTo().alert();
	  Reporter.log("Switched to Confirmation Alert |");
	  
	  String confirmAlertText = confirmAlert.getText();
	  Reporter.log("Confirmation Alert Text is: "+ confirmAlertText+" |");
	  
	  confirmAlert.accept();
	  Reporter.log("Confirmation Alert Accepted |");
	  
	  Reporter.log("Confirmation Alert Case Ended |");
  }
  
  @Test(priority=2)
  public void promptAlertTestCase() {
	  Reporter.log("Prompt Alert Case Started |");
	  driver.findElement(By.xpath("//button[@id='prompt']")).click();
	  Reporter.log("Prompt Alert button Clicked |");
	  
	  Alert promptAlert = driver.switchTo().alert();
	  Reporter.log("Switched to Prompt Alert |");
	  
	  promptAlert.sendKeys("This is a prompt alert");
	  Reporter.log("Prompt Alert Text entered |");
	  
	  promptAlert.accept();
	  Reporter.log("Prompt Alert Accepted |");
	  
	  Reporter.log("Prompt Alert Case Ended |");
  }
  
  @BeforeMethod
  public void beforeMethod() {
	  driver.switchTo().defaultContent();
  }

  @BeforeTest
  public void driverInstance() {
	  driver= new ChromeDriver();
	  driver.get("https://www.training-support.net/selenium/javascript-alerts");
	  driver.manage().window().maximize();
	  Reporter.log("Opened Browser");
	  
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  Reporter.log("Page title is: "+ driver.getTitle());
  }

  @AfterTest
  public void closeBrowser() {
	  driver.close();
  }

}
