package testNGTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.util.concurrent.TimeUnit;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Activity7 {
  WebDriver driver;
    
  @BeforeClass(alwaysRun = true)
  public void driverInstance() {
	  driver= new ChromeDriver();
	  driver.get("https://www.training-support.net/selenium/login-form");
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }
  @DataProvider(name = "Authentication")
  public static Object[][] dataproviderMethod(){
	  return new Object[][] {{"admin","password"}};
  }
  @Test(dataProvider = "Authentication")
  public void login(String username,String password) {
	  WebDriverWait wait = new WebDriverWait(driver, 40);
	  WebElement uname= driver.findElement(By.xpath("//input[@id='username']"));
	  WebElement pwd = driver.findElement(By.xpath("//input[@id='password']"));
	  WebElement loginButton = driver.findElement(By.xpath("//button[contains(text(),'Log in')]"));
	  
	  uname.sendKeys(username);
	  pwd.sendKeys(password);
	  System.out.println("Credentials entered successfully.");
	  loginButton.click();
	  
	  String messagePath = "//div[@id='action-confirmation']";
	  WebElement message = driver.findElement(By.xpath(messagePath));
	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(messagePath)));
	  Assert.assertEquals("Welcome Back, admin",message.getText());
  }
  
  @AfterClass(alwaysRun = true)
  public void closeBrowser() {
	  driver.close();
  }

}
