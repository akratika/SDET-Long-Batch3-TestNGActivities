package testNGTests;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Activity5 {
  WebDriver driver;
  
  @BeforeClass(alwaysRun = true)
  public void driverInstance() {
	  driver= new ChromeDriver();
	  driver.get("https://www.training-support.net/selenium/target-practice");
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }
  
  @Test(groups= {"HeaderTests","ButtonTests"})
  public void pageTitle() {
	  String title = driver.getTitle();
	  System.out.println("Title is: "+ title);
	  Assert.assertEquals("Target Practice", title);
  }
  
  @Test(dependsOnMethods= {"pageTitle"},groups= {"HeaderTests"})
  public void headerTest1() {
	  WebElement thirdHeader = driver.findElement(By.xpath("//div/h3[@id='third-header']"));
	  System.out.println("Third header is: "+ thirdHeader.getText());
	  Assert.assertEquals("Third header", thirdHeader.getText());
  }
  
  @Test(dependsOnMethods= {"pageTitle"},groups= {"HeaderTests"})
  public void headerTest2() {
	  WebElement fifthHeader = driver.findElement(By.xpath("//div/h5[@class='ui green header']"));
	  System.out.println("Fifth header is: "+ fifthHeader.getText());
	  
	  Assert.assertEquals(fifthHeader.getCssValue("background-color"), "rgba(33, 186, 69, 1)");
  }
  
  @Test(dependsOnMethods= {"pageTitle"},groups= {"ButtonTests"})
  public void buttonTest1() {
	  WebElement oliveButton = driver.findElement(By.xpath("//button[@class='ui olive button']"));
	  System.out.println("Button text is: "+ oliveButton.getText());
	  Assert.assertEquals("Olive", oliveButton.getText());
  }
  
  @Test(dependsOnMethods= {"pageTitle"},groups= {"ButtonTests"})
  public void buttonTest2() {
	  WebElement brownButton = driver.findElement(By.xpath("//button[@class='ui brown button']"));
	  System.out.println("Button text is: "+ brownButton.getText());
	  Assert.assertEquals(brownButton.getCssValue("background-color"), "rgb(165, 103, 63)");
  }
  
  @AfterClass(alwaysRun = true)
  public void closeBrowser() {
	  driver.close();
  }

}
