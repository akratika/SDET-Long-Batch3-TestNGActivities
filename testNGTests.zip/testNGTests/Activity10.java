package testNGTests;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;


public class Activity10 {
	WebDriver driver;
	Actions builder;
	
  @Test(priority=0)
  public void middleValue() throws InterruptedException {
	  WebElement slider = driver.findElement(By.id("slider"));
	  slider.click();
		
	  String volumeLevel = driver.findElement(By.cssSelector("span#value")).getText();
	  Reporter.log("Mid Value: "+ volumeLevel);
	  
	  Assert.assertEquals(volumeLevel, "50");
  }
  @Test(priority=1)
  public void maxValue() {
	  WebElement slider = driver.findElement(By.id("slider"));
	  builder.clickAndHold(slider).moveByOffset(100, 0).release().build().perform();
	  
	  String volumeLevel = driver.findElement(By.cssSelector("span#value")).getText();
	  Reporter.log("Max Value: "+ volumeLevel);
	  
	  Assert.assertEquals(volumeLevel, "100");
  }
  @Test(priority=2)
  public void minValue() {
	  WebElement slider = driver.findElement(By.id("slider"));
	  builder.clickAndHold(slider).moveByOffset(-100, 0).release().build().perform();
	  
	  String volumeLevel = driver.findElement(By.cssSelector("span#value")).getText();
	  Reporter.log("Min Value: "+ volumeLevel);
	  
	  Assert.assertEquals(volumeLevel, "0");
  }
  @Test(priority=3)
  public void per30Value() {
	  WebElement slider = driver.findElement(By.id("slider"));
	  builder.clickAndHold(slider).moveByOffset(-21, 0).release().build().perform();
	  
	  String volumeLevel = driver.findElement(By.cssSelector("span#value")).getText();
	  Reporter.log("Slider percent Value: "+ volumeLevel);
	  
	  Assert.assertEquals(volumeLevel, "30");
  }
  @Test(priority=4)
  public void per80Value() {
	  WebElement slider = driver.findElement(By.id("slider"));
	  builder.clickAndHold(slider).moveByOffset(34, 0).release().build().perform();
	  
	  String volumeLevel = driver.findElement(By.cssSelector("span#value")).getText();
	  Reporter.log("Slider percent Value: "+ volumeLevel);
	  
	  Assert.assertEquals(volumeLevel, "80");
  }
  @BeforeClass
  public void driverInstance() {
	  driver= new ChromeDriver();
	  builder= new Actions(driver);
	  driver.get("https://www.training-support.net/selenium/sliders");
	  driver.manage().window().maximize();
	  	  
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @AfterClass
  public void closeBrowser() {
	  driver.close();
  }

}
